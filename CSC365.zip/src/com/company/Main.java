package com.company;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Collector;
import org.jsoup.select.Elements;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.*;

public class Main implements ActionListener {
    private static JLabel label;
    private static JTextField userText;
    private static JButton button;
    private static JLabel output;
    private static JTextField output1;

    Hashtablea hashtablea = new Hashtablea();

    public static void main(String[] args) {


                JPanel panel = new JPanel();
                JFrame frame = new JFrame();
                frame.setSize(1000, 500);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
                frame.add(panel);

              //  panel.setLayout(null);

                 label = new JLabel("Enter your website");
                label.setBounds(10,20,120,25);
                panel.add(label);

                 userText = new JTextField(20);
                userText.setBounds(130,20,300,25);
                panel.add(userText);

                 button = new JButton("Search");
                button.setBounds(50,50,80,25);
                button.addActionListener(new Main());
                panel.add(button);


                output = new JLabel("Output");
                output.setBounds(10,110,300,25);
                panel.add(output);

                 output1 = new JTextField(20);
                 output1.setBounds(50,130,300,25);
                 panel.add(output1);




                frame.setVisible(true);
    }




    @Override
    public void actionPerformed(ActionEvent e) { //click action
       //String user = userText.getText(); //get url from user


        try {

            // get userInput URL and Parsing the url and add to one hashtable.
            //single hashtable
            Hashtablea ht = Parser.ParserURL(userText.getText()); // 입력값


            // get All urls from my txt file and Parsing the urls and add to ArrayList of hashtable.
            // 10 hashtables
            ArrayList<Hashtablea> tables = Parser.store(); //전체



            // add one hash table to ArrayList of hashtable from user input url
            tables.add(ht);//size 11
            //this is for add all tfidf values from my txt file
            List<Double> listA = new ArrayList<Double>();




            // calculate all urls and add tfidf values to the listA
            //10 hashtables has 10 tfidf values
                for (Hashtablea t : tables) {
                    double b = 0;

                    for (ArrayList<Entry> en : t.hashtable) { //checking  ArrayList entry of one hashtable
                        if (en == null) { //if it is null then continue; [ <10>,<>,<20>,<1>,<5> ...<n>]
                            continue;
                        }
                        for (Entry entr : en) { //checking entry of Arraylist Entry
                            if (entr == null) { // if it is null then continue; [ <E1>, <E2>,<E3>,<>,<E4>]
                                continue;
                            }

                            b += TFIDF.tfidf(t, tables, entr.getKey(), tables.size()); //calculate tfidf and add all tfidf values to b
                            //  +=  because there are many entries so add all tfidf value and get one tfidf value.
                            // += compound addition assignment operator

                        }

                    }
                    // tfidf values to list of listA
                    listA.add(b);
                }

            double a=0;                  // get tfidf value from user input
            for(ArrayList<Entry> entries: ht.hashtable) { // check ArrayList<Entry> from one hashtable. This hashtable made by User input

                if(entries == null ){  // check null [ <10>,<>,<20>,<1>,<5> ...<n>]
                    continue;
                }


                for (Entry entry : entries) {  //checking entry of Arraylist Entry
                    if(entry == null){
                        continue;
                    }/////////////////////////////////////
                    a += TFIDF.tfidf(ht, tables, entry.getKey(), tables.size()); ///calculate tfidf value



                }


            }



//this is for compare 10 tfidf values from Arraylist hashtable(tables) and 1 tfidf value from hashtable(ht)
          //find the approximate value
           double min = Double.MAX_VALUE; //차이값의 절대값 저장
           Hashtablea result = hashtablea;
           for(int i = 0; i < listA.size()-1; i++){
               double abs = Math.abs(listA.get(i) - a); //차이값 절대값 반환
               //System.out.println(listA.get(i));
               //System.out.println(tables.get(i).url);
               if(abs < min){ // 절대값이 최소값보다 작으면
                   min = abs; // 최소값 교체

                   result = tables.get(i); //result get hashtable inside ArrayList hashtable

               }

           }
            String z = result.url;
            System.out.println(z);
           output = new JLabel();
           output1.setText(z);

        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }
}

////       Hashtablea hash = new Hashtablea();
////        hash.put("go",20);
////        System.out.println(hash.capacity);
////        System.out.println(hash.numberofItems);
////        System.out.println(hash.toString());
////     System.out.println(hash.get("go"));
////        hash.put("zx",22);
////        System.out.println(hash.capacity);
////        System.out.println(hash.numberofItems);
//
//        //Path PATH = FileSystems.getDefault().getPath("urls.txt");
//        File file = new File("C:\\Source\\CSC365\\out\\production\\CSC365\\com\\company\\urls.txt");
//        Scanner sc = new Scanner(file);
//        ArrayList<String> url = new ArrayList<>(10); //url 정렬해서 담기
//        ArrayList<Hashtablea> tables = new ArrayList<>(10);
//        //Hashtablea hashtable = new Hashtablea();
//
//        Scanner in = new Scanner(System.in);
//        String str = in.next();
//
//
//       // System.out.println(url);
//
//        while (sc.hasNext()) { //읽기
//            url.add(sc.next()); // url에 담기
//            //ArrayList<Hashtablea> tables = new ArrayList<>(10); // 해시 테이블 만들기
//        }
//       // System.out.println(url);
//
//
//        Document input = Jsoup.connect(str).get();
//        Element metaTaginput = input.getElementById("bodyContent");
//
//     //   url.get(1);
//        for (int i=0; i<url.size(); i++) {
//            Document doc = Jsoup.connect(url.get(i)).get();
//            Element metaTags = doc.getElementById("bodyContent");
//
//
//            //System.out.println(url.get(i));
//            String metaTag = metaTags.text().toLowerCase(Locale.ROOT);
//            String[] splitStr = metaTag.split(" ");//문자열을 공백을 기준으로 잘라서 배열에 저장
//            Hashtablea hashtable = new Hashtablea();
//            //  Hashtablea hashtable = new Hashtablea();
//            for (String s : splitStr) {
//                hashtable.put(s, 1);
//                // System.out.println(hashtable.toString());.
//                //System.out.println(hashtable.get(s));
//                //  System.out.println("word:"+s + " count:"+ hashtable.get(s));
//
//                // System.out.println(TFIDF.tfidf(hashtable,tables,, tables.size()));
//            }
//            //ArrayList<Hashtablea>[] tables = new  ArrayList[10]; // 해시 테이블 만들기
////            ArrayList<Hashtablea> tables = new ArrayList<>(10);
//            tables.add(hashtable);
//
//
//            System.out.println(hashtable);
//        }
//      //-------  TFIDF.tfidf(hashtable,tables, key., tables.size());
//
////----해시테이블에 저장 그리고 해시테이블 배열로 저장
//
//
////                for (int j=0; j<splitStr.length; j++){
////                hashtablea.put(splitStr[j],1);
////                // System.out.println(hashtable.toString());.
////                // System.out.println(hashtable.get(s));
////            }
//
//           // Hashtablea hashtable = new Hashtablea();
//            //hashtable.setUrl(url.get(i));
//
////        hashtable.put("hi", 1);
////        System.out.println(hashtable);
////        hashtable.put("go",2);
////        System.out.println(hashtable.toString());
//
////            for (String s : splitStr) {
////                hashtable.put(s, 1);
////                // System.out.println(hashtable.toString());.
//                // System.out.println(hashtable.get(s));
//
//
//        //Entry[] e = new Entry[Hashtablea];
////        int capacity = 4;
////        Entry entry = new Entry(String key,int value);
////
//
////
////        System.out.println(TFIDF.tfidf(hashtable,tables, , tables.size()));
//
//            // for (int i=0; i<splitStr.length; i++){
//            //            hashtable.put(splitStr[i],1 );
//            //           // System.out.println(hashtable.toString());.
//            //            System.out.println(hashtable.get(splitStr[i]));
//            //            }
//
//
//            // hashtable.
//
//        }

    //}





