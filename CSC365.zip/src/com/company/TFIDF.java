package com.company;

import java.util.ArrayList;

public class TFIDF{





//Term Frequency


// Term Frequency -- checking document inside of word if it contains term(word or key) then increase numberOfTimesWordUsed
    public static double tf(Hashtablea doc, String term) {

        if(doc.contains(term)){
            return doc.numberOfTimesWordUsed;
        }else {
            return 0;
        }
        }



//IDF is calculated by dividing the total number of documents by the number of documents in the collection containing the term.


    // counting how many documents It has and divided by number of documents with term in it
    ////------- log (총 문서 / 총 문서에서 포함된 단어)
    public static double idf(ArrayList<Hashtablea> docs, String term, int total) {

        for (Hashtablea words : docs) {
            if (words.contains(term)) {
                return Math.log(total/words.numberOfTimesWordUsed);           //total is total number of documents  11 = user input + txt file url
                                                            // words.numberOfTimesWordUsed is number of documents with term in it
                                                            // number of documents / document frequency
            } else {
                return 0;
            }
        }
        return 0;
                                                        //why we use log base
                                                        // if our IDF was not a log(IDF) then definitely
                                                        // it would have dominated the TF but if taken as log(IDF)
                                                        //then it would have a equal effect on the result as TF has.
                                                        //ex) total(1000) / 1(rare word) = 1000 but if log base then 3
    }

//------- 총 문서 / 총 문서에서 포함된 단어
    public static double tfidf(Hashtablea doc, ArrayList<Hashtablea> docs,String term, int total){

        return tf(doc,term) * idf(docs,term,total);
    }





//     Inverse document frequency)
//
//    TFIDF
//
//    TF/IDF = TF*IDF



}





