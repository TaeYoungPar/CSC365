package com.company;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class Parser {

    public static Hashtablea ParserURL(String url) throws IOException {
        Hashtablea hashtable = new Hashtablea();
        hashtable.url = url;
        Document doc = Jsoup.connect(url).get();                 //use jsoup and get url
        Element metaTags = doc.getElementById("bodyContent");    //get body contents


        String metaTag = metaTags.text().toLowerCase(Locale.ROOT);   //change every word to lowercase
        String[] splitStr = metaTag.split(" ");//문자열을 공백을 기준으로 잘라서 배열에 저장  break down every word into the array

        for (String s : splitStr) { // get word inside of array
            hashtable.put(s, 1);     // put every word to hashtable

        }
        return hashtable;
    }

// this is for parsing all urls from my txt file and add into ArrayList hashtable
    public static ArrayList<Hashtablea> store() throws IOException {
        ArrayList<String> urls = new ArrayList<>(10);
        ArrayList<Hashtablea> hashtableas = new ArrayList<>(10);
        File file = new File("C:\\Source\\CSC365\\out\\production\\CSC365\\com\\company\\urls.txt");
        Scanner sc = new Scanner(file);

        while (sc.hasNext()) { //읽기
            urls.add(sc.next()); // url에 담기
            //ArrayList<Hashtablea> tables = new ArrayList<>(10); // 해시 테이블 만들기
        }
        for (String url : urls) {
            hashtableas.add(ParserURL(url));       //parsing every urls and add to Arraylist hashtable
        }
        sc.close();
        return hashtableas;
    }
}

