package com.company;

public class Entry {

     String key;
     int value;
     int numberOfTimesWordUsed = 1;





    public Entry(String key, int value) {
            this.key = key;
            this.value = value;



        }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;

    }




}


