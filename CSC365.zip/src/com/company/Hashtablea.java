package com.company;

import java.util.ArrayList;

public class Hashtablea {
    int capacity = 4; //size(how big,how many numberofItems can store)
    int numberofItems = 0; // numberofItems (how many elements in hashtable)
    double loadfactor = 0.75;
    int numberOfTimesWordUsed = 1; // how many times used(word frequency)
    public ArrayList<Entry>[] hashtable;  // ArrayList<Hashtable> tables // Hashtable hashtable // ArrayList<Entry> Entries // Entry entry
    String url;
     public Hashtablea() {
         hashtable = new ArrayList[capacity];
     }

    public int hash(String key){
        return Math.abs(key.hashCode()) % capacity; //positive number    // key.hashCode = 4 capacity =4 4%4 == 0 store at the beginning  5 % 4  1p    6%4 2p
    }

    public void put(String key, int value) {
//        if (numberofItems >= capacity * loadfactor) {
//            resize();
//        }

        int index = hash(key);  //hashing

        if(hashtable[index] == null){                      // if null then add key and value also increase numberofItems
            hashtable[index] = new ArrayList<Entry>();
            hashtable[index].add(new Entry(key,value));
            numberofItems++;                             //how many elements in hashtable
        }else { // collision happened
            for(Entry e: hashtable[index]){
                if(e.getKey().equalsIgnoreCase(key)){         //if there is exactly same key then increase numberofTimesWordUsed
                    e.numberOfTimesWordUsed++;
                    return;
                }
            }
            hashtable[index].add(new Entry(key,value));    // otherwise, no define then add key and value also increase numberofItem
            numberofItems++;


        if (numberofItems >= capacity * loadfactor) {                // if numberofItem is bigger than capacity * loadfactor then resize
            resize();
        }

    }}


    public void resize(){

         ArrayList<Entry>[] tmpHashTable = hashtable;                      //make new hashtable with 2 times the capacity
        capacity = capacity*2;
        hashtable = new ArrayList[capacity];
        numberofItems = 0;                                               //clear numberofIteams becuase if not it will be old hashtable numberofIteams + new hashtable numberofIteams

        for(ArrayList<Entry> e : tmpHashTable) {                         // add every key and value to new hashtable
            if (e == null) {
                continue;
            }for (Entry entry : e) {
                    put(entry.getKey(), entry.getValue());

                }
            }
    }


    public boolean contains(String key){
        int index = hash(key);
//        ArrayList<Entry> hashtable[index] = hashtable[index];
        if(hashtable[index] == null){
         return false;
        }
        for (Entry e: hashtable[index]) {
//            if (e == null) {
//                continue;
//            }

                if (e.getKey().equalsIgnoreCase(key)) {
                    return true;
                }
            }

        return false;
    }
}


